# Moodle-Resource-Fetcher
A Firefox extension which helps students download all their course resource in a click.
